import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { csvData, columns } = await req.json();
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");

    if (!LOVABLE_API_KEY) {
      throw new Error("LOVABLE_API_KEY is not configured");
    }

    console.log("Analyzing CSV with columns:", columns);
    console.log("Data rows:", csvData.length);

    // Prepare data summary for AI analysis
    const dataSummary = {
      totalRows: csvData.length,
      columns: columns,
      sampleData: csvData.slice(0, 5), // First 5 rows as sample
      dataTypes: columns.reduce((acc: any, col: string) => {
        const values = csvData.map((row: any) => row[col]).filter(Boolean);
        const numericValues = values.filter((v: any) => !isNaN(Number(v)));
        acc[col] = numericValues.length > values.length * 0.8 ? 'numeric' : 'categorical';
        return acc;
      }, {})
    };

    // Call Lovable AI for insights
    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          {
            role: "system",
            content: `You are a data analysis assistant. Analyze CSV data and provide actionable insights. 
            Always respond with valid JSON in this exact format:
            {
              "insights": [
                {"title": "string", "description": "string", "category": "trend|pattern|anomaly|summary"}
              ],
              "suggestedCharts": [
                {
                  "type": "bar|line|pie|area|scatter",
                  "title": "string",
                  "xAxis": "column_name",
                  "yAxis": "column_name",
                  "description": "string"
                }
              ],
              "summary": {
                "keyMetrics": [{"label": "string", "value": "string"}],
                "overview": "string"
              }
            }`
          },
          {
            role: "user",
            content: `Analyze this CSV data and provide insights:
            
            Total Rows: ${dataSummary.totalRows}
            Columns: ${JSON.stringify(dataSummary.columns)}
            Data Types: ${JSON.stringify(dataSummary.dataTypes)}
            Sample Data: ${JSON.stringify(dataSummary.sampleData)}
            
            Provide:
            1. Key insights about patterns, trends, or anomalies
            2. Suggested visualizations with specific column mappings
            3. Summary with key metrics
            
            Respond ONLY with valid JSON, no markdown formatting.`
          }
        ],
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(
          JSON.stringify({ error: "Rate limits exceeded, please try again later." }),
          { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      if (response.status === 402) {
        return new Response(
          JSON.stringify({ error: "Payment required, please add funds to your Lovable AI workspace." }),
          { status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      const errorText = await response.text();
      console.error("AI gateway error:", response.status, errorText);
      return new Response(
        JSON.stringify({ error: "AI gateway error" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const aiResponse = await response.json();
    let analysisResult = aiResponse.choices[0].message.content;
    
    // Clean up markdown formatting if present
    analysisResult = analysisResult.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim();
    
    console.log("AI Analysis Result:", analysisResult);
    
    const analysis = JSON.parse(analysisResult);

    return new Response(
      JSON.stringify({ 
        analysis,
        metadata: {
          totalRows: dataSummary.totalRows,
          columns: dataSummary.columns,
          dataTypes: dataSummary.dataTypes
        }
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("Error in analyze-csv function:", error);
    return new Response(
      JSON.stringify({ 
        error: error instanceof Error ? error.message : "Unknown error",
        details: error instanceof Error ? error.stack : undefined
      }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});