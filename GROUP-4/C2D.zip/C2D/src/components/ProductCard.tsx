import { useState } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { ShoppingCart } from "lucide-react";
import { useCartStore } from "@/stores/cartStore";
import type { ShopifyProduct } from "@/lib/shopify";
import { toast } from "sonner";

interface ProductCardProps {
  product: ShopifyProduct;
}

export const ProductCard = ({ product }: ProductCardProps) => {
  const [isAdding, setIsAdding] = useState(false);
  const addItem = useCartStore(state => state.addItem);
  
  const { node } = product;
  const image = node.images.edges[0]?.node;
  const price = node.priceRange.minVariantPrice;
  const defaultVariant = node.variants.edges[0]?.node;

  const handleAddToCart = async (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (!defaultVariant) return;
    
    setIsAdding(true);
    
    const cartItem = {
      product,
      variantId: defaultVariant.id,
      variantTitle: defaultVariant.title,
      price: defaultVariant.price,
      quantity: 1,
      selectedOptions: defaultVariant.selectedOptions || []
    };
    
    addItem(cartItem);
    
    toast.success("Added to cart!", {
      description: node.title,
      position: "top-center",
    });
    
    setTimeout(() => setIsAdding(false), 500);
  };

  return (
    <Link to={`/product/${node.handle}`}>
      <Card className="group overflow-hidden transition-all hover:shadow-lg hover:shadow-primary/10">
        <CardContent className="p-0">
          <div className="aspect-square overflow-hidden bg-secondary/20">
            {image ? (
              <img
                src={image.url}
                alt={image.altText || node.title}
                className="w-full h-full object-cover transition-transform group-hover:scale-105"
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center text-muted-foreground">
                No image
              </div>
            )}
          </div>
        </CardContent>
        
        <CardFooter className="flex flex-col items-start gap-2 p-4">
          <h3 className="font-semibold text-lg line-clamp-1">{node.title}</h3>
          <div className="flex items-center justify-between w-full">
            <p className="text-xl font-bold text-primary">
              {price.currencyCode} ${parseFloat(price.amount).toFixed(2)}
            </p>
            <Button
              size="sm"
              onClick={handleAddToCart}
              disabled={isAdding || !defaultVariant?.availableForSale}
              className="gap-2"
            >
              <ShoppingCart className="h-4 w-4" />
              {isAdding ? "Adding..." : "Add"}
            </Button>
          </div>
        </CardFooter>
      </Card>
    </Link>
  );
};
