import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Plus, X } from "lucide-react";

interface CustomChart {
  id: string;
  type: string;
  title: string;
  xAxis: string;
  yAxis: string;
  description: string;
}

interface ChartBuilderProps {
  columns: string[];
  onAddChart: (chart: CustomChart) => void;
  customCharts: CustomChart[];
  onRemoveChart: (id: string) => void;
}

const ChartBuilder = ({ columns, onAddChart, customCharts, onRemoveChart }: ChartBuilderProps) => {
  const [chartType, setChartType] = useState("bar");
  const [chartTitle, setChartTitle] = useState("");
  const [xAxis, setXAxis] = useState("");
  const [yAxis, setYAxis] = useState("");

  const handleAddChart = () => {
    if (!chartTitle || !xAxis || !yAxis) return;

    const newChart: CustomChart = {
      id: Date.now().toString(),
      type: chartType,
      title: chartTitle,
      xAxis,
      yAxis,
      description: `Custom ${chartType} chart`,
    };

    onAddChart(newChart);
    
    // Reset form
    setChartTitle("");
    setXAxis("");
    setYAxis("");
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Plus className="w-5 h-5" />
          Custom Chart Builder
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label>Chart Type</Label>
            <Select value={chartType} onValueChange={setChartType}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="bar">Bar Chart</SelectItem>
                <SelectItem value="line">Line Chart</SelectItem>
                <SelectItem value="pie">Pie Chart</SelectItem>
                <SelectItem value="area">Area Chart</SelectItem>
                <SelectItem value="scatter">Scatter Plot</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Chart Title</Label>
            <Input
              placeholder="e.g., Sales by Region"
              value={chartTitle}
              onChange={(e) => setChartTitle(e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label>X-Axis Column</Label>
            <Select value={xAxis} onValueChange={setXAxis}>
              <SelectTrigger>
                <SelectValue placeholder="Select column" />
              </SelectTrigger>
              <SelectContent>
                {columns.map(col => (
                  <SelectItem key={col} value={col}>{col}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Y-Axis Column</Label>
            <Select value={yAxis} onValueChange={setYAxis}>
              <SelectTrigger>
                <SelectValue placeholder="Select column" />
              </SelectTrigger>
              <SelectContent>
                {columns.map(col => (
                  <SelectItem key={col} value={col}>{col}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <Button
          onClick={handleAddChart}
          className="w-full"
          disabled={!chartTitle || !xAxis || !yAxis}
        >
          <Plus className="w-4 h-4 mr-2" />
          Add Chart
        </Button>

        {customCharts.length > 0 && (
          <div className="mt-4 space-y-2">
            <Label className="text-sm font-medium">Custom Charts ({customCharts.length})</Label>
            <div className="space-y-2">
              {customCharts.map(chart => (
                <div
                  key={chart.id}
                  className="flex items-center justify-between p-2 bg-muted/50 rounded-lg"
                >
                  <div className="flex-1">
                    <p className="text-sm font-medium">{chart.title}</p>
                    <p className="text-xs text-muted-foreground">
                      {chart.type} • {chart.xAxis} vs {chart.yAxis}
                    </p>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => onRemoveChart(chart.id)}
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default ChartBuilder;