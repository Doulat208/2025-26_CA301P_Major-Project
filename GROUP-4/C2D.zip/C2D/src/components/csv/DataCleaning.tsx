import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Trash2, Check } from "lucide-react";

interface DataCleaningProps {
  data: any[];
  columns: string[];
  onCleanData: (cleanedData: any[]) => void;
}

const DataCleaning = ({ data, columns, onCleanData }: DataCleaningProps) => {
  const [options, setOptions] = useState({
    removeDuplicates: false,
    removeEmptyRows: false,
    fillMissingWithZero: false,
    trimWhitespace: false,
  });

  const [stats, setStats] = useState({
    duplicates: 0,
    emptyRows: 0,
    missingValues: 0,
  });

  useEffect(() => {
    // Calculate statistics
    const duplicateCount = data.length - new Set(data.map(row => JSON.stringify(row))).size;
    const emptyRowCount = data.filter(row => 
      columns.every(col => !row[col] || String(row[col]).trim() === '')
    ).length;
    const missingCount = data.reduce((sum, row) => 
      sum + columns.filter(col => !row[col] || String(row[col]).trim() === '').length, 0
    );

    setStats({
      duplicates: duplicateCount,
      emptyRows: emptyRowCount,
      missingValues: missingCount,
    });
  }, [data, columns]);

  const handleClean = () => {
    let cleanedData = [...data];

    if (options.removeDuplicates) {
      const seen = new Set();
      cleanedData = cleanedData.filter(row => {
        const key = JSON.stringify(row);
        if (seen.has(key)) return false;
        seen.add(key);
        return true;
      });
    }

    if (options.removeEmptyRows) {
      cleanedData = cleanedData.filter(row =>
        columns.some(col => row[col] && String(row[col]).trim() !== '')
      );
    }

    if (options.fillMissingWithZero) {
      cleanedData = cleanedData.map(row => {
        const newRow = { ...row };
        columns.forEach(col => {
          if (!newRow[col] || String(newRow[col]).trim() === '') {
            newRow[col] = '0';
          }
        });
        return newRow;
      });
    }

    if (options.trimWhitespace) {
      cleanedData = cleanedData.map(row => {
        const newRow = { ...row };
        columns.forEach(col => {
          if (newRow[col]) {
            newRow[col] = String(newRow[col]).trim();
          }
        });
        return newRow;
      });
    }

    onCleanData(cleanedData);
  };

  const toggleOption = (key: keyof typeof options) => {
    setOptions(prev => ({ ...prev, [key]: !prev[key] }));
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Trash2 className="w-5 h-5" />
          Data Cleaning
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-3 gap-4 p-4 bg-muted/50 rounded-lg">
          <div className="text-center">
            <p className="text-2xl font-bold text-destructive">{stats.duplicates}</p>
            <p className="text-xs text-muted-foreground">Duplicate Rows</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold text-orange-500">{stats.emptyRows}</p>
            <p className="text-xs text-muted-foreground">Empty Rows</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold text-yellow-500">{stats.missingValues}</p>
            <p className="text-xs text-muted-foreground">Missing Values</p>
          </div>
        </div>

        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Checkbox
                id="duplicates"
                checked={options.removeDuplicates}
                onCheckedChange={() => toggleOption('removeDuplicates')}
              />
              <Label htmlFor="duplicates" className="cursor-pointer">
                Remove duplicate rows
              </Label>
            </div>
            {stats.duplicates > 0 && (
              <Badge variant="destructive">{stats.duplicates}</Badge>
            )}
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Checkbox
                id="empty"
                checked={options.removeEmptyRows}
                onCheckedChange={() => toggleOption('removeEmptyRows')}
              />
              <Label htmlFor="empty" className="cursor-pointer">
                Remove empty rows
              </Label>
            </div>
            {stats.emptyRows > 0 && (
              <Badge variant="destructive">{stats.emptyRows}</Badge>
            )}
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Checkbox
                id="missing"
                checked={options.fillMissingWithZero}
                onCheckedChange={() => toggleOption('fillMissingWithZero')}
              />
              <Label htmlFor="missing" className="cursor-pointer">
                Fill missing values with 0
              </Label>
            </div>
            {stats.missingValues > 0 && (
              <Badge variant="secondary">{stats.missingValues}</Badge>
            )}
          </div>

          <div className="flex items-center space-x-2">
            <Checkbox
              id="whitespace"
              checked={options.trimWhitespace}
              onCheckedChange={() => toggleOption('trimWhitespace')}
            />
            <Label htmlFor="whitespace" className="cursor-pointer">
              Trim whitespace from all cells
            </Label>
          </div>
        </div>

        <Button
          onClick={handleClean}
          className="w-full"
          disabled={!Object.values(options).some(Boolean)}
        >
          <Check className="w-4 h-4 mr-2" />
          Apply Cleaning
        </Button>
      </CardContent>
    </Card>
  );
};

export default DataCleaning;