import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { TrendingUp, AlertCircle, BarChart3, Info, X } from "lucide-react";

interface Insight {
  title: string;
  description: string;
  category: string;
}

interface Summary {
  keyMetrics: Array<{ label: string; value: string }>;
  overview: string;
}

interface InsightsPanelProps {
  insights: Insight[];
  summary: Summary;
}

const categoryIcons: Record<string, any> = {
  trend: TrendingUp,
  pattern: BarChart3,
  anomaly: AlertCircle,
  summary: Info,
};

const categoryColors: Record<string, string> = {
  trend: "bg-blue-500/10 text-blue-500 border-blue-500/20",
  pattern: "bg-purple-500/10 text-purple-500 border-purple-500/20",
  anomaly: "bg-red-500/10 text-red-500 border-red-500/20",
  summary: "bg-green-500/10 text-green-500 border-green-500/20",
};

const InsightsPanel = ({ insights, summary }: InsightsPanelProps) => {
  const [selectedCategories, setSelectedCategories] = useState<string[]>([
    "trend",
    "pattern",
    "anomaly",
    "summary",
  ]);

  const toggleCategory = (category: string) => {
    setSelectedCategories((prev) =>
      prev.includes(category)
        ? prev.filter((c) => c !== category)
        : [...prev, category]
    );
  };

  const filteredInsights = insights.filter((insight) =>
    selectedCategories.includes(insight.category)
  );

  const categories = Array.from(new Set(insights.map((i) => i.category)));

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-br from-card to-accent/20">
        <CardHeader>
          <CardTitle>Summary</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm text-muted-foreground">{summary.overview}</p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {summary.keyMetrics.map((metric, idx) => (
              <div key={idx} className="text-center p-3 bg-background rounded-lg">
                <p className="text-2xl font-bold text-primary">{metric.value}</p>
                <p className="text-xs text-muted-foreground mt-1">{metric.label}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Filter Insights</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-2">
            {categories.map((category) => {
              const isSelected = selectedCategories.includes(category);
              const Icon = categoryIcons[category] || Info;
              const colorClass = categoryColors[category] || categoryColors.summary;

              return (
                <Button
                  key={category}
                  variant={isSelected ? "default" : "outline"}
                  size="sm"
                  onClick={() => toggleCategory(category)}
                  className={!isSelected ? colorClass : ""}
                >
                  <Icon className="w-3 h-3 mr-1" />
                  {category}
                  {isSelected && <X className="w-3 h-3 ml-1" />}
                </Button>
              );
            })}
          </div>
        </CardContent>
      </Card>

      <div className="grid md:grid-cols-2 gap-4">
        {filteredInsights.length === 0 ? (
          <Card className="col-span-2">
            <CardContent className="py-8 text-center text-muted-foreground">
              No insights to show. Select at least one category above.
            </CardContent>
          </Card>
        ) : (
          filteredInsights.map((insight, idx) => {
            const Icon = categoryIcons[insight.category] || Info;
            const colorClass = categoryColors[insight.category] || categoryColors.summary;

            return (
              <Card key={idx} className="hover:shadow-lg transition-shadow">
                <CardHeader className="flex flex-row items-start justify-between space-y-0 pb-2">
                  <CardTitle className="text-base font-semibold">
                    {insight.title}
                  </CardTitle>
                  <Badge variant="outline" className={colorClass}>
                    <Icon className="w-3 h-3 mr-1" />
                    {insight.category}
                  </Badge>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">{insight.description}</p>
                </CardContent>
              </Card>
            );
          })
        )}
      </div>
    </div>
  );
};

export default InsightsPanel;