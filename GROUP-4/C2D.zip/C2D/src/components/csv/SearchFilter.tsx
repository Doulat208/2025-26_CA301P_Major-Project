import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Search } from "lucide-react";

interface SearchFilterProps {
  searchTerm: string;
  onSearchChange: (term: string) => void;
  columns: string[];
  selectedColumns: string[];
  onColumnsChange: (columns: string[]) => void;
}

const SearchFilter = ({
  searchTerm,
  onSearchChange,
  columns,
  selectedColumns,
  onColumnsChange,
}: SearchFilterProps) => {
  const handleColumnToggle = (column: string) => {
    if (selectedColumns.includes(column)) {
      onColumnsChange(selectedColumns.filter((c) => c !== column));
    } else {
      onColumnsChange([...selectedColumns, column]);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg">Search & Filter</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search across selected columns..."
            value={searchTerm}
            onChange={(e) => onSearchChange(e.target.value)}
            className="pl-9"
          />
        </div>

        <div>
          <Label className="text-sm font-medium mb-2 block">Visible Columns</Label>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {columns.map((column) => (
              <div key={column} className="flex items-center space-x-2">
                <Checkbox
                  id={column}
                  checked={selectedColumns.includes(column)}
                  onCheckedChange={() => handleColumnToggle(column)}
                />
                <label
                  htmlFor={column}
                  className="text-sm cursor-pointer leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                >
                  {column}
                </label>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default SearchFilter;