import { useState } from "react";
import { Upload, Settings } from "lucide-react";
import Papa from "papaparse";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import { supabase } from "@/integrations/supabase/client";
import DataTable from "@/components/csv/DataTable";
import InsightsPanel from "@/components/csv/InsightsPanel";
import ChartsPanel from "@/components/csv/ChartsPanel";
import SearchFilter from "@/components/csv/SearchFilter";
import DataCleaning from "@/components/csv/DataCleaning";
import ChartBuilder from "@/components/csv/ChartBuilder";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface CSVData {
  headers: string[];
  rows: any[];
}

interface Analysis {
  insights: Array<{
    title: string;
    description: string;
    category: string;
  }>;
  suggestedCharts: Array<{
    type: string;
    title: string;
    xAxis: string;
    yAxis: string;
    description: string;
  }>;
  summary: {
    keyMetrics: Array<{ label: string; value: string }>;
    overview: string;
  };
}

interface CustomChart {
  id: string;
  type: string;
  title: string;
  xAxis: string;
  yAxis: string;
  description: string;
}

const CSVDashboard = () => {
  const [csvData, setCSVData] = useState<CSVData | null>(null);
  const [analysis, setAnalysis] = useState<Analysis | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedColumns, setSelectedColumns] = useState<string[]>([]);
  const [customCharts, setCustomCharts] = useState<CustomChart[]>([]);
  const { toast } = useToast();

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (file.type !== "text/csv" && !file.name.endsWith(".csv")) {
      toast({
        title: "Invalid file type",
        description: "Please upload a CSV file",
        variant: "destructive",
      });
      return;
    }

    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: async (results) => {
        if (results.data.length === 0) {
          toast({
            title: "Empty file",
            description: "The CSV file is empty",
            variant: "destructive",
          });
          return;
        }

        const headers = Object.keys(results.data[0] as any);
        setCSVData({
          headers,
          rows: results.data as any[],
        });
        setSelectedColumns(headers);

        toast({
          title: "File uploaded successfully",
          description: `Loaded ${results.data.length} rows`,
        });

        // Automatically analyze the data
        await analyzeData(results.data, headers);
      },
      error: (error) => {
        toast({
          title: "Error parsing CSV",
          description: error.message,
          variant: "destructive",
        });
      },
    });
  };

  const analyzeData = async (data: any[], columns: string[]) => {
    setIsAnalyzing(true);
    try {
      const { data: result, error } = await supabase.functions.invoke("analyze-csv", {
        body: {
          csvData: data,
          columns: columns,
        },
      });

      if (error) throw error;

      setAnalysis(result.analysis);
      toast({
        title: "Analysis complete",
        description: "AI insights generated successfully",
      });
    } catch (error: any) {
      console.error("Analysis error:", error);
      toast({
        title: "Analysis failed",
        description: error.message || "Failed to analyze CSV data",
        variant: "destructive",
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleCleanData = (cleanedData: any[]) => {
    setCSVData(prev => prev ? { ...prev, rows: cleanedData } : null);
    toast({
      title: "Data cleaned",
      description: `${cleanedData.length} rows after cleaning`,
    });
    // Re-analyze with cleaned data
    if (csvData) {
      analyzeData(cleanedData, csvData.headers);
    }
  };

  const handleAddChart = (chart: CustomChart) => {
    setCustomCharts(prev => [...prev, chart]);
    toast({
      title: "Chart added",
      description: `${chart.title} has been added`,
    });
  };

  const handleRemoveChart = (id: string) => {
    setCustomCharts(prev => prev.filter(c => c.id !== id));
    toast({
      title: "Chart removed",
    });
  };

  const filteredData = csvData
    ? {
        ...csvData,
        rows: csvData.rows.filter((row) =>
          selectedColumns.some((col) =>
            String(row[col]).toLowerCase().includes(searchTerm.toLowerCase())
          )
        ),
      }
    : null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-secondary/10">
      <div className="container mx-auto py-8 px-4">
        <div className="mb-8 text-center">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent mb-2">
            CSV to Dashboard
          </h1>
          <p className="text-muted-foreground">
            Upload your CSV and get AI-powered insights instantly
          </p>
        </div>

        {!csvData ? (
          <div className="max-w-2xl mx-auto">
            <label
              htmlFor="csv-upload"
              className="flex flex-col items-center justify-center w-full h-64 border-2 border-dashed border-border rounded-lg cursor-pointer bg-card hover:bg-accent/50 transition-colors"
            >
              <div className="flex flex-col items-center justify-center pt-5 pb-6">
                <Upload className="w-12 h-12 mb-4 text-muted-foreground" />
                <p className="mb-2 text-sm text-foreground">
                  <span className="font-semibold">Click to upload</span> or drag and drop
                </p>
                <p className="text-xs text-muted-foreground">CSV files only</p>
              </div>
              <input
                id="csv-upload"
                type="file"
                className="hidden"
                accept=".csv"
                onChange={handleFileUpload}
              />
            </label>
          </div>
        ) : (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <Button
                variant="outline"
                onClick={() => {
                  setCSVData(null);
                  setAnalysis(null);
                  setSearchTerm("");
                  setCustomCharts([]);
                }}
              >
                Upload New File
              </Button>
              <Button
                onClick={() => analyzeData(csvData.rows, csvData.headers)}
                disabled={isAnalyzing}
              >
                {isAnalyzing ? "Analyzing..." : "Re-analyze Data"}
              </Button>
            </div>

            <Tabs defaultValue="overview" className="w-full">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="insights">Insights</TabsTrigger>
                <TabsTrigger value="charts">Charts</TabsTrigger>
                <TabsTrigger value="clean">
                  <Settings className="w-4 h-4 mr-2" />
                  Clean Data
                </TabsTrigger>
              </TabsList>

              <TabsContent value="overview" className="space-y-6">
                <SearchFilter
                  searchTerm={searchTerm}
                  onSearchChange={setSearchTerm}
                  columns={csvData.headers}
                  selectedColumns={selectedColumns}
                  onColumnsChange={setSelectedColumns}
                />
                <DataTable
                  headers={selectedColumns}
                  rows={filteredData?.rows || []}
                />
              </TabsContent>

              <TabsContent value="insights" className="space-y-6">
                {analysis ? (
                  <InsightsPanel
                    insights={analysis.insights}
                    summary={analysis.summary}
                  />
                ) : (
                  <div className="text-center py-12 text-muted-foreground">
                    Click "Re-analyze Data" to generate insights
                  </div>
                )}
              </TabsContent>

              <TabsContent value="charts" className="space-y-6">
                <ChartBuilder
                  columns={csvData.headers}
                  onAddChart={handleAddChart}
                  customCharts={customCharts}
                  onRemoveChart={handleRemoveChart}
                />
                {analysis && (
                  <>
                    <div className="text-sm font-medium text-muted-foreground">
                      AI-Suggested Charts
                    </div>
                    <ChartsPanel
                      charts={analysis.suggestedCharts}
                      data={filteredData?.rows || []}
                    />
                  </>
                )}
                {customCharts.length > 0 && (
                  <>
                    <div className="text-sm font-medium text-muted-foreground">
                      Your Custom Charts
                    </div>
                    <ChartsPanel
                      charts={customCharts}
                      data={filteredData?.rows || []}
                    />
                  </>
                )}
              </TabsContent>

              <TabsContent value="clean" className="space-y-6">
                <DataCleaning
                  data={csvData.rows}
                  columns={csvData.headers}
                  onCleanData={handleCleanData}
                />
              </TabsContent>
            </Tabs>
          </div>
        )}
      </div>
    </div>
  );
};

export default CSVDashboard;