import { Header } from "@/components/Header";
import { ProductGrid } from "@/components/ProductGrid";

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main>
        {/* Hero Section */}
        <section className="bg-gradient-to-b from-secondary/30 to-background py-16 px-4">
          <div className="container mx-auto text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-4 bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
              Exquisite Bangles Collection
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto">
              Discover handcrafted elegance with our stunning collection of traditional and contemporary bangles
            </p>
          </div>
        </section>

        {/* Products Section */}
        <section className="py-12 px-4">
          <div className="container mx-auto">
            <div className="mb-8">
              <h2 className="text-2xl md:text-3xl font-bold mb-2">Our Collection</h2>
              <p className="text-muted-foreground">Browse our beautiful selection of bangles</p>
            </div>
            
            <ProductGrid />
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="border-t py-8 px-4 mt-20">
        <div className="container mx-auto text-center text-muted-foreground">
          <p>&copy; 2024 Bangle Elegance. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
};

export default Index;
