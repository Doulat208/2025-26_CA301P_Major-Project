import { Link } from 'react-router-dom';

export function Logo({ className = '' }: { className?: string }) {
  return (
    <Link to="/" className={`flex items-center gap-2 ${className}`}>
      <div className="relative">
        <svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
          {/* Bus body */}
          <rect x="8" y="18" width="32" height="18" rx="3" className="fill-primary" />
          {/* Bus roof/luggage */}
          <rect x="12" y="12" width="24" height="8" rx="2" className="fill-primary" />
          {/* Windows */}
          <rect x="12" y="22" width="6" height="6" rx="1" fill="white" />
          <rect x="21" y="22" width="6" height="6" rx="1" fill="white" />
          <rect x="30" y="22" width="6" height="6" rx="1" fill="white" />
          {/* Wheels */}
          <circle cx="16" cy="36" r="4" className="fill-primary" />
          <circle cx="32" cy="36" r="4" className="fill-primary" />
          <circle cx="16" cy="36" r="2" fill="white" />
          <circle cx="32" cy="36" r="2" fill="white" />
          {/* Antenna/flag */}
          <line x1="36" y1="12" x2="40" y2="6" stroke="hsl(var(--primary))" strokeWidth="2" />
          <polygon points="40,4 44,8 40,8" className="fill-primary" />
        </svg>
      </div>
      <span className="text-xl font-bold text-primary tracking-tight">
        COMPANI<span className="text-primary/80">O</span>
      </span>
    </Link>
  );
}
