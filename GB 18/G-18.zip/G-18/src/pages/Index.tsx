import { Link } from 'react-router-dom';
import { Navbar } from '@/components/Navbar';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/AuthContext';
import heroImage from '@/assets/hero-traveler.jpg';
import rishikeshImg from '@/assets/destinations/rishikesh.jpg';
import mussorieImg from '@/assets/destinations/mussoorie.jpg';
import goaImg from '@/assets/destinations/goa.jpg';
import shimlaImg from '@/assets/destinations/shimla.jpg';
import manaliImg from '@/assets/destinations/manali.jpg';
import { Bot, Search, Calendar, Heart, MapPin } from 'lucide-react';

const destinations = [
  { name: 'Rishikesh', image: rishikeshImg, tagline: 'Adventure & Spirituality' },
  { name: 'Mussoorie', image: mussorieImg, tagline: 'Queen of Hills' },
  { name: 'Goa', image: goaImg, tagline: 'Beach Paradise' },
  { name: 'Shimla', image: shimlaImg, tagline: 'Colonial Charm' },
  { name: 'Manali', image: manaliImg, tagline: 'Mountain Escape' },
];

const features = [
  {
    icon: Search,
    title: 'Find Your Match',
    description: 'Search by destination and interests to find travel companions with similar goals and passions.',
  },
  {
    icon: Calendar,
    title: 'Plan Together',
    description: 'Manage your travel preferences, set your budget, and plan your trip dates all in one place.',
  },
  {
    icon: Heart,
    title: 'Create Memories',
    description: 'Connect with like-minded travelers and create unforgettable memories together around the world.',
  },
];

const Index = () => {
  const { user } = useAuth();

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      {/* Hero Section */}
      <section className="container mx-auto px-4 py-8 lg:py-16">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="space-y-6 animate-fade-in">
            <p className="text-sm font-semibold text-primary uppercase tracking-wider">
              Travel Solo, Never Alone
            </p>
            
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-primary leading-tight">
              Find your<br />
              Companio, and<br />
              <span className="text-gradient">Explore together</span>
            </h1>
            
            <p className="text-lg text-muted-foreground max-w-md">
              Find like-minded travel companions, explore new destinations together, 
              and create unforgettable memories with Companio.
            </p>
            
            <div className="flex flex-wrap items-center gap-4 pt-4">
              <Link to={user ? "/find-buddy" : "/signup"}>
                <Button size="lg" className="px-8 py-6 text-base font-semibold">
                  Find Buddy
                </Button>
              </Link>
              
              <button className="flex items-center gap-3 px-4 py-3 hover:bg-muted rounded-full transition-colors">
                <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                  <Bot className="w-5 h-5 text-primary" />
                </div>
                <span className="font-medium text-foreground">AI Companio</span>
              </button>
            </div>
          </div>

          {/* Right Image */}
          <div className="relative animate-fade-in" style={{ animationDelay: '0.2s' }}>
            <img 
              src={heroImage} 
              alt="Happy traveler with backpack sitting on orange suitcase" 
              className="w-full h-auto object-contain"
            />
          </div>
        </div>
      </section>

      {/* About Section - Why Choose Companio */}
      <section id="about" className="py-16 lg:py-24 bg-muted/50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
              Why Choose Companio?
            </h2>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              Connect with fellow travelers and make meaningful friendships
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <div 
                key={feature.title}
                className="bg-background rounded-xl p-8 border border-border hover:shadow-lg transition-shadow animate-fade-in"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <div className="w-12 h-12 bg-primary rounded-lg flex items-center justify-center mb-6">
                  <feature.icon className="w-6 h-6 text-primary-foreground" />
                </div>
                <h3 className="text-xl font-bold text-foreground mb-3">{feature.title}</h3>
                <p className="text-muted-foreground leading-relaxed">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Destinations Section */}
      <section id="destinations" className="py-16 lg:py-24">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
              Popular Destinations
            </h2>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              Explore breathtaking places and find travel companions heading there
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 md:gap-6">
            {destinations.map((destination, index) => (
              <div 
                key={destination.name}
                className="group relative aspect-[3/4] rounded-xl overflow-hidden cursor-pointer animate-fade-in"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <img 
                  src={destination.image} 
                  alt={destination.name}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
                {/* Overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-foreground/80 via-foreground/20 to-transparent" />
                
                {/* Content */}
                <div className="absolute bottom-0 left-0 right-0 p-4 text-primary-foreground">
                  <div className="flex items-center gap-1 mb-1 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <MapPin className="w-3 h-3" />
                    <span className="text-xs">{destination.tagline}</span>
                  </div>
                  <h3 className="text-lg md:text-xl font-bold">{destination.name}</h3>
                </div>

                {/* Hover effect border */}
                <div className="absolute inset-0 border-2 border-transparent group-hover:border-primary rounded-xl transition-colors duration-300" />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 lg:py-24 bg-primary">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-primary-foreground mb-4">
            Ready to find your travel companion?
          </h2>
          <p className="text-primary-foreground/80 text-lg mb-8 max-w-xl mx-auto">
            Join thousands of solo travelers exploring the world together
          </p>
          <Link to={user ? "/find-buddy" : "/signup"}>
            <Button 
              size="lg" 
              variant="secondary"
              className="px-8 py-6 text-base font-semibold bg-background text-primary hover:bg-background/90"
            >
              Get Started Today
            </Button>
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 bg-background border-t border-border">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-8">
            <div>
              <h4 className="font-bold text-foreground mb-4">About</h4>
              <ul className="space-y-2">
                <li>
                  <button 
                    onClick={() => document.getElementById('about')?.scrollIntoView({ behavior: 'smooth' })}
                    className="text-muted-foreground hover:text-primary transition-colors"
                  >
                    About Us
                  </button>
                </li>
                <li>
                  <a href="#" className="text-muted-foreground hover:text-primary transition-colors">Blog</a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-foreground mb-4">Travel</h4>
              <ul className="space-y-2">
                <li>
                  <button 
                    onClick={() => document.getElementById('destinations')?.scrollIntoView({ behavior: 'smooth' })}
                    className="text-muted-foreground hover:text-primary transition-colors"
                  >
                    Destinations
                  </button>
                </li>
                <li>
                  <Link to="/find-buddy" className="text-muted-foreground hover:text-primary transition-colors">
                    Find Buddy
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-foreground mb-4">Legal</h4>
              <ul className="space-y-2">
                <li>
                  <a href="#" className="text-muted-foreground hover:text-primary transition-colors">Privacy Policy</a>
                </li>
                <li>
                  <a href="#" className="text-muted-foreground hover:text-primary transition-colors">Terms of Service</a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-foreground mb-4">Connect</h4>
              <ul className="space-y-2">
                <li>
                  <a href="#" className="text-muted-foreground hover:text-primary transition-colors">Twitter</a>
                </li>
                <li>
                  <a href="#" className="text-muted-foreground hover:text-primary transition-colors">Instagram</a>
                </li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-border pt-8 text-center">
            <p className="text-muted-foreground">
              © 2025 Companio. All rights reserved. Travel solo, never alone.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;
