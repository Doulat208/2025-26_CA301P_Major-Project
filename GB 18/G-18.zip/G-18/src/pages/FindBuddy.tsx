import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Navbar } from '@/components/Navbar';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { Search, MapPin, User, Heart, Loader2 } from 'lucide-react';

interface BuddyProfile {
  id: string;
  name: string;
  interests: string[];
  hobbies: string[];
  destination: string | null;
}

const FindBuddy = () => {
  const { user, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const [profiles, setProfiles] = useState<BuddyProfile[]>([]);
  const [filteredProfiles, setFilteredProfiles] = useState<BuddyProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [destinationSearch, setDestinationSearch] = useState('');
  const [interestSearch, setInterestSearch] = useState('');

  useEffect(() => {
    if (!authLoading && !user) {
      navigate('/signin');
    }
  }, [user, authLoading, navigate]);

  useEffect(() => {
    if (user) {
      fetchProfiles();
    }
  }, [user]);

  useEffect(() => {
    filterProfiles();
  }, [destinationSearch, interestSearch, profiles]);

  const fetchProfiles = async () => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('id, name, interests, hobbies, destination')
        .neq('user_id', user?.id || '');

      if (error) throw error;
      
      setProfiles(data || []);
      setFilteredProfiles(data || []);
    } catch (error) {
      console.error('Error fetching profiles:', error);
    } finally {
      setLoading(false);
    }
  };

  const filterProfiles = () => {
    let filtered = profiles;

    if (destinationSearch.trim()) {
      filtered = filtered.filter(profile => 
        profile.destination?.toLowerCase().includes(destinationSearch.toLowerCase())
      );
    }

    if (interestSearch.trim()) {
      filtered = filtered.filter(profile => 
        profile.interests?.some(interest => 
          interest.toLowerCase().includes(interestSearch.toLowerCase())
        )
      );
    }

    setFilteredProfiles(filtered);
  };

  const handleSearch = () => {
    filterProfiles();
  };

  if (authLoading || loading) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="flex items-center justify-center h-[calc(100vh-4rem)]">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <main className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-primary mb-2">Find Your Travel Buddy</h1>
            <p className="text-muted-foreground">
              Search for like-minded travelers by destination or interests
            </p>
          </div>

          {/* Search Filters */}
          <Card className="mb-8">
            <CardContent className="pt-6">
              <div className="grid md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium flex items-center gap-2">
                    <MapPin className="w-4 h-4" />
                    Destination
                  </label>
                  <Input
                    placeholder="e.g., Bali, Thailand"
                    value={destinationSearch}
                    onChange={(e) => setDestinationSearch(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium flex items-center gap-2">
                    <Heart className="w-4 h-4" />
                    Interest
                  </label>
                  <Input
                    placeholder="e.g., Photography, Hiking"
                    value={interestSearch}
                    onChange={(e) => setInterestSearch(e.target.value)}
                  />
                </div>
                <div className="flex items-end">
                  <Button onClick={handleSearch} className="w-full">
                    <Search className="w-4 h-4 mr-2" />
                    Search
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Results */}
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">
              {filteredProfiles.length} {filteredProfiles.length === 1 ? 'buddy' : 'buddies'} found
            </p>

            {filteredProfiles.length === 0 ? (
              <Card>
                <CardContent className="py-12 text-center">
                  <User className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
                  <p className="text-lg font-medium text-foreground mb-2">No buddies found</p>
                  <p className="text-muted-foreground">
                    Try adjusting your search filters or check back later
                  </p>
                </CardContent>
              </Card>
            ) : (
              <div className="grid md:grid-cols-2 gap-4">
                {filteredProfiles.map((profile) => (
                  <Card key={profile.id} className="hover:shadow-md transition-shadow">
                    <CardContent className="pt-6">
                      <div className="flex items-start gap-4">
                        <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0">
                          <User className="w-6 h-6 text-primary" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <h3 className="font-semibold text-foreground truncate">{profile.name}</h3>
                          {profile.destination && (
                            <p className="text-sm text-muted-foreground flex items-center gap-1 mt-1">
                              <MapPin className="w-3 h-3" />
                              {profile.destination}
                            </p>
                          )}
                          
                          {profile.interests && profile.interests.length > 0 && (
                            <div className="mt-3">
                              <p className="text-xs text-muted-foreground mb-2">Interests</p>
                              <div className="flex flex-wrap gap-1">
                                {profile.interests.slice(0, 4).map((interest) => (
                                  <Badge key={interest} variant="secondary" className="text-xs">
                                    {interest}
                                  </Badge>
                                ))}
                                {profile.interests.length > 4 && (
                                  <Badge variant="outline" className="text-xs">
                                    +{profile.interests.length - 4}
                                  </Badge>
                                )}
                              </div>
                            </div>
                          )}

                          {profile.hobbies && profile.hobbies.length > 0 && (
                            <div className="mt-2">
                              <p className="text-xs text-muted-foreground mb-2">Hobbies</p>
                              <div className="flex flex-wrap gap-1">
                                {profile.hobbies.slice(0, 3).map((hobby) => (
                                  <Badge key={hobby} variant="outline" className="text-xs">
                                    {hobby}
                                  </Badge>
                                ))}
                                {profile.hobbies.length > 3 && (
                                  <Badge variant="outline" className="text-xs">
                                    +{profile.hobbies.length - 3}
                                  </Badge>
                                )}
                              </div>
                            </div>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
};

export default FindBuddy;
