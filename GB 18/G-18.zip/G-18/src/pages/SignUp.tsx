import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Logo } from '@/components/Logo';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useAuth } from '@/contexts/AuthContext';
import { Eye, EyeOff, Plane } from 'lucide-react';
import signupImage from '@/assets/signup-traveler.jpg';
import { z } from 'zod';

const signUpSchema = z.object({
  name: z.string().min(2, 'Name must be at least 2 characters').max(100),
  email: z.string().email('Please enter a valid email').max(255),
  password: z.string().min(6, 'Password must be at least 6 characters'),
});

const SignUp = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState<{ name?: string; email?: string; password?: string }>({});
  
  const { signUp, user } = useAuth();
  const navigate = useNavigate();

  // Redirect if already logged in
  if (user) {
    navigate('/');
    return null;
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrors({});
    
    const validation = signUpSchema.safeParse({ name, email, password });
    if (!validation.success) {
      const fieldErrors: { name?: string; email?: string; password?: string } = {};
      validation.error.errors.forEach((err) => {
        if (err.path[0]) {
          fieldErrors[err.path[0] as keyof typeof fieldErrors] = err.message;
        }
      });
      setErrors(fieldErrors);
      return;
    }

    setLoading(true);
    const { error } = await signUp(email, password, name);
    setLoading(false);
    
    if (!error) {
      navigate('/');
    }
  };

  return (
    <div className="min-h-screen flex">
      {/* Left Side - Image */}
      <div className="hidden lg:flex lg:flex-1 relative overflow-hidden">
        <img 
          src={signupImage} 
          alt="Traveler looking at ocean view" 
          className="w-full h-full object-cover"
        />
        <div className="absolute top-8 left-8 flex items-center gap-4">
          <Logo />
          <span className="text-sm font-semibold text-primary uppercase tracking-wider">
            Travel Solo, Never Alone
          </span>
        </div>
      </div>

      {/* Right Side - Form */}
      <div className="flex-1 flex flex-col justify-center px-8 lg:px-16 xl:px-24 bg-background relative">
        <div className="lg:hidden mb-8">
          <Logo />
        </div>
        
        {/* Decorative Plane */}
        <div className="absolute top-8 right-8 hidden lg:block">
          <Plane className="w-8 h-8 text-primary animate-float" style={{ transform: 'rotate(-45deg)' }} />
          <svg className="absolute top-4 left-full" width="100" height="40" viewBox="0 0 100 40">
            <path 
              d="M0,20 Q30,5 60,15 T100,10" 
              stroke="hsl(var(--primary))" 
              strokeWidth="1" 
              strokeDasharray="4 4" 
              fill="none"
            />
          </svg>
        </div>

        <div className="max-w-md w-full mx-auto">
          <h1 className="text-4xl font-bold text-primary mb-8 text-center lg:text-left">Welcome</h1>

          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="space-y-2">
              <Label htmlFor="name">Full Name</Label>
              <Input
                id="name"
                type="text"
                placeholder="John Doe"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="h-12"
              />
              {errors.name && <p className="text-sm text-destructive">{errors.name}</p>}
            </div>

            <div className="space-y-2">
              <Label htmlFor="email">E-mail</Label>
              <Input
                id="email"
                type="email"
                placeholder="example@gmail.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="h-12"
              />
              {errors.email && <p className="text-sm text-destructive">{errors.email}</p>}
            </div>

            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <div className="relative">
                <Input
                  id="password"
                  type={showPassword ? 'text' : 'password'}
                  placeholder="@#%$"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="h-12 pr-12"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                >
                  {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
              {errors.password && <p className="text-sm text-destructive">{errors.password}</p>}
            </div>

            <Button type="submit" className="w-full h-12 text-base" disabled={loading}>
              {loading ? 'Creating account...' : 'Sign Up'}
            </Button>
          </form>

          <p className="text-center text-muted-foreground mt-6">
            Already have an account?{' '}
            <Link to="/signin" className="text-primary font-medium underline underline-offset-4">
              Sign In
            </Link>
          </p>
        </div>

        {/* Decorative mosque/landmark silhouette */}
        <div className="absolute bottom-0 right-0 hidden lg:block opacity-10">
          <svg width="200" height="150" viewBox="0 0 200 150" className="text-primary fill-current">
            <path d="M30,150 L30,100 Q50,70 70,100 L70,150 Z" />
            <path d="M80,150 L80,80 Q100,40 120,80 L120,150 Z" />
            <path d="M130,150 L130,100 Q150,70 170,100 L170,150 Z" />
            <rect x="0" y="140" width="200" height="10" />
          </svg>
        </div>
      </div>
    </div>
  );
};

export default SignUp;
