import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Navbar } from '@/components/Navbar';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { User, MapPin, Calendar, DollarSign, Heart, Compass, X, Plus, Loader2 } from 'lucide-react';

interface Profile {
  id: string;
  name: string;
  email: string;
  interests: string[];
  hobbies: string[];
  destination: string | null;
  budget: string | null;
  travel_date_start: string | null;
  travel_date_end: string | null;
}

const Profile = () => {
  const { user, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [editing, setEditing] = useState(false);

  // Form state
  const [name, setName] = useState('');
  const [destination, setDestination] = useState('');
  const [budget, setBudget] = useState('');
  const [travelDateStart, setTravelDateStart] = useState('');
  const [travelDateEnd, setTravelDateEnd] = useState('');
  const [interests, setInterests] = useState<string[]>([]);
  const [hobbies, setHobbies] = useState<string[]>([]);
  const [newInterest, setNewInterest] = useState('');
  const [newHobby, setNewHobby] = useState('');

  useEffect(() => {
    if (!authLoading && !user) {
      navigate('/signin');
    }
  }, [user, authLoading, navigate]);

  useEffect(() => {
    if (user) {
      fetchProfile();
    }
  }, [user]);

  const fetchProfile = async () => {
    if (!user) return;
    
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('user_id', user.id)
        .maybeSingle();

      if (error) throw error;
      
      if (data) {
        setProfile(data);
        setName(data.name || '');
        setDestination(data.destination || '');
        setBudget(data.budget || '');
        setTravelDateStart(data.travel_date_start || '');
        setTravelDateEnd(data.travel_date_end || '');
        setInterests(data.interests || []);
        setHobbies(data.hobbies || []);
      }
    } catch (error) {
      console.error('Error fetching profile:', error);
      toast.error('Failed to load profile');
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    if (!user) return;
    
    setSaving(true);
    try {
      const { error } = await supabase
        .from('profiles')
        .update({
          name,
          destination: destination || null,
          budget: budget || null,
          travel_date_start: travelDateStart || null,
          travel_date_end: travelDateEnd || null,
          interests,
          hobbies,
        })
        .eq('user_id', user.id);

      if (error) throw error;
      
      toast.success('Profile updated successfully!');
      setEditing(false);
      fetchProfile();
    } catch (error) {
      console.error('Error updating profile:', error);
      toast.error('Failed to update profile');
    } finally {
      setSaving(false);
    }
  };

  const addInterest = () => {
    if (newInterest.trim() && !interests.includes(newInterest.trim())) {
      setInterests([...interests, newInterest.trim()]);
      setNewInterest('');
    }
  };

  const removeInterest = (interest: string) => {
    setInterests(interests.filter(i => i !== interest));
  };

  const addHobby = () => {
    if (newHobby.trim() && !hobbies.includes(newHobby.trim())) {
      setHobbies([...hobbies, newHobby.trim()]);
      setNewHobby('');
    }
  };

  const removeHobby = (hobby: string) => {
    setHobbies(hobbies.filter(h => h !== hobby));
  };

  if (authLoading || loading) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="flex items-center justify-center h-[calc(100vh-4rem)]">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <main className="container mx-auto px-4 py-8">
        <div className="max-w-3xl mx-auto">
          <div className="flex items-center justify-between mb-8">
            <h1 className="text-3xl font-bold text-primary">My Profile</h1>
            {!editing ? (
              <Button onClick={() => setEditing(true)}>Edit Profile</Button>
            ) : (
              <div className="flex gap-2">
                <Button variant="outline" onClick={() => { setEditing(false); fetchProfile(); }}>
                  Cancel
                </Button>
                <Button onClick={handleSave} disabled={saving}>
                  {saving ? 'Saving...' : 'Save Changes'}
                </Button>
              </div>
            )}
          </div>

          <div className="space-y-6">
            {/* Basic Info */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="w-5 h-5" />
                  Basic Information
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Name</Label>
                    {editing ? (
                      <Input value={name} onChange={(e) => setName(e.target.value)} />
                    ) : (
                      <p className="text-foreground font-medium">{profile?.name || '-'}</p>
                    )}
                  </div>
                  <div className="space-y-2">
                    <Label>Email</Label>
                    <p className="text-foreground font-medium">{profile?.email || '-'}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Travel Preferences */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Compass className="w-5 h-5" />
                  Travel Preferences
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label className="flex items-center gap-2">
                      <MapPin className="w-4 h-4" />
                      Destination
                    </Label>
                    {editing ? (
                      <Input 
                        value={destination} 
                        onChange={(e) => setDestination(e.target.value)} 
                        placeholder="e.g., Bali, Thailand"
                      />
                    ) : (
                      <p className="text-foreground">{profile?.destination || 'Not set'}</p>
                    )}
                  </div>
                  <div className="space-y-2">
                    <Label className="flex items-center gap-2">
                      <DollarSign className="w-4 h-4" />
                      Budget
                    </Label>
                    {editing ? (
                      <Input 
                        value={budget} 
                        onChange={(e) => setBudget(e.target.value)} 
                        placeholder="e.g., $1000-2000"
                      />
                    ) : (
                      <p className="text-foreground">{profile?.budget || 'Not set'}</p>
                    )}
                  </div>
                </div>
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label className="flex items-center gap-2">
                      <Calendar className="w-4 h-4" />
                      Travel Date Start
                    </Label>
                    {editing ? (
                      <Input 
                        type="date"
                        value={travelDateStart} 
                        onChange={(e) => setTravelDateStart(e.target.value)} 
                      />
                    ) : (
                      <p className="text-foreground">{profile?.travel_date_start || 'Not set'}</p>
                    )}
                  </div>
                  <div className="space-y-2">
                    <Label className="flex items-center gap-2">
                      <Calendar className="w-4 h-4" />
                      Travel Date End
                    </Label>
                    {editing ? (
                      <Input 
                        type="date"
                        value={travelDateEnd} 
                        onChange={(e) => setTravelDateEnd(e.target.value)} 
                      />
                    ) : (
                      <p className="text-foreground">{profile?.travel_date_end || 'Not set'}</p>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Interests */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Heart className="w-5 h-5" />
                  Interests
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2 mb-4">
                  {interests.length === 0 ? (
                    <p className="text-muted-foreground">No interests added yet</p>
                  ) : (
                    interests.map((interest) => (
                      <Badge key={interest} variant="secondary" className="px-3 py-1">
                        {interest}
                        {editing && (
                          <button onClick={() => removeInterest(interest)} className="ml-2">
                            <X className="w-3 h-3" />
                          </button>
                        )}
                      </Badge>
                    ))
                  )}
                </div>
                {editing && (
                  <div className="flex gap-2">
                    <Input
                      value={newInterest}
                      onChange={(e) => setNewInterest(e.target.value)}
                      placeholder="Add an interest"
                      onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addInterest())}
                    />
                    <Button type="button" variant="outline" size="icon" onClick={addInterest}>
                      <Plus className="w-4 h-4" />
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Hobbies */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Compass className="w-5 h-5" />
                  Hobbies
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2 mb-4">
                  {hobbies.length === 0 ? (
                    <p className="text-muted-foreground">No hobbies added yet</p>
                  ) : (
                    hobbies.map((hobby) => (
                      <Badge key={hobby} variant="outline" className="px-3 py-1">
                        {hobby}
                        {editing && (
                          <button onClick={() => removeHobby(hobby)} className="ml-2">
                            <X className="w-3 h-3" />
                          </button>
                        )}
                      </Badge>
                    ))
                  )}
                </div>
                {editing && (
                  <div className="flex gap-2">
                    <Input
                      value={newHobby}
                      onChange={(e) => setNewHobby(e.target.value)}
                      placeholder="Add a hobby"
                      onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addHobby())}
                    />
                    <Button type="button" variant="outline" size="icon" onClick={addHobby}>
                      <Plus className="w-4 h-4" />
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Profile;
